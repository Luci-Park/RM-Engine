/**
 * @file $safeitemname$.cpp
 * @author $username$
 * @brief // TODO: Add a brief description of this class
 *
 * @copyright Copyright (c) 2025 - RM Engine
 *
 */

#include "pch.h"
#include "$safeitemname$.h"

namespace rm
{

} // rm namespace