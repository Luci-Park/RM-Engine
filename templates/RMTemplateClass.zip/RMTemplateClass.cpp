/**
 * @file $safeitemname$.cpp
 * @author $username$
 * @brief // TODO: Add a brief description of this class
 * @version 0.1
 * @date $time$
 *
 * @copyright Copyright (c) 2025 - RM Engine
 *
 */

#include "prc.h"
#include "$safeitemname$.h"

namespace rm
{

} // rm namespace