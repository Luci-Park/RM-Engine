/**
 * @file $safeitemname$.cpp
 * @author $username$
 * @brief // TODO: Add a brief description of this header
 * @version 0.1
 * @date $time$
 *
 * @copyright Copyright (c) 2025 - RM Engine
 *
 */

#pragma once

namespace rm
{
    class $safeitemname$
    {
    public:
    private:
    };

} // rm namespace